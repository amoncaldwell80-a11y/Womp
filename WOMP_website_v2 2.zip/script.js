const CONTRACT="F1oENDA4DBJZhuLN8q12PbqgSAaMHFNidTMyJPfVpump";
async function copyCA(btn) {
  try {
    await navigator.clipboard.writeText(CONTRACT);
    const old=btn.textContent; btn.textContent="COPIED ✓";
    setTimeout(()=>btn.textContent=old,1600);
  } catch { btn.textContent="COPY MANUALLY"; }
}
document.getElementById("copy").addEventListener("click",()=>copyCA(document.getElementById("copy")));
document.getElementById("copy2").addEventListener("click",()=>copyCA(document.getElementById("copy2")));
document.getElementById("year").textContent=new Date().getFullYear();
