# WOMP $WOMP — Website v2

This is a static WOMP landing page ready for GitHub Pages.

## Official links configured
- X: https://x.com/wompdd
- Telegram: https://t.me/WOMPCommunity
- Pump.fun: https://solana.pump.fun/coin/F1oENDA4DBJZhuLN8q12PbqgSAaMHFNidTMyJPfVpump
- Contract: F1oENDA4DBJZhuLN8q12PbqgSAaMHFNidTMyJPfVpump

## Files
- index.html
- styles.css
- script.js
- womp-meme.png

## Publish
Create a GitHub repository, upload these files to the root, then:
**Settings → Pages → Build and deployment → Source: Deploy from a branch → main → /(root) → Save.**

GitHub Pages publishes static HTML/CSS/JavaScript from a repository. See:
https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

Important: verify the Telegram username and all official links before publishing.
